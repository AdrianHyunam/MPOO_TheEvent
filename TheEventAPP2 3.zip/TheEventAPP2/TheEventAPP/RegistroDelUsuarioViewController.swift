//
//  RegistroDelUsuarioViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class RegistroDelUsuarioViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

    }
    
    

}
