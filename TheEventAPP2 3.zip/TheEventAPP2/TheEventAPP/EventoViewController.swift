//
//  EventoViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class EventoViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    var eventos: [Evento] = [Evento(nombre: "Musical", imagen: "la.png", fecha: ["Hoy-Mero"])]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return eventos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cat1", for: indexPath) as! EventoCollectionViewCell
        cell.backgroundColor = UIColor.red
        cell.texto.text = eventos[indexPath.row].nombre
        
        
        return cell
    }
    
}
