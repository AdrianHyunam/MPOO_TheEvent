//
//  EventoCollectionViewCell.swift
//  TheEventAPP
//
//  Created by Macbook on 11/15/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class EventoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var texto: UILabel!
    @IBOutlet weak var imagen: UIImageView!
    
}
