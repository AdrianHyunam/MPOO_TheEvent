//
//  RegistroDelUsuarioViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import Firebase

class RegistroDelUsuarioViewController: UIViewController, UITextFieldDelegate{
    
    @IBOutlet weak var progresoDelRegistro: UIProgressView!
    
    @IBOutlet weak var vistaDeCategorias: UIStackView!
    @IBOutlet weak var categorias: UILabel!
    @IBOutlet weak var stack1DeCat: UIStackView!
    @IBOutlet weak var cat1: UILabel!
    @IBOutlet weak var switch1: UISwitch!
    @IBOutlet weak var stack2DeCat: UIStackView!
    @IBOutlet weak var cat2: UILabel!
    @IBOutlet weak var switch2: UISwitch!
    @IBOutlet weak var stack3DeCat: UIStackView!
    @IBOutlet weak var cat3: UILabel!
    @IBOutlet weak var switch3: UISwitch!
    @IBOutlet weak var stack4DeCat: UIStackView!
    @IBOutlet weak var cat4: UILabel!
    @IBOutlet weak var switch4: UISwitch!
    @IBOutlet weak var stack5DeCat: UIStackView!
    @IBOutlet weak var cat5: UILabel!
    @IBOutlet weak var switch5: UISwitch!
    @IBOutlet weak var stack6DeCat: UIStackView!
    @IBOutlet weak var cat6: UILabel!
    @IBOutlet weak var switch6: UISwitch!
    
    @IBOutlet weak var vistaDelRegistroFinal: UIStackView!
    @IBOutlet weak var Usuario: UITextField!
    @IBOutlet weak var Correo: UITextField!
    @IBOutlet weak var Contraseña: UITextField!
    @IBOutlet weak var Aviso: UILabel!
    
    @IBOutlet weak var BotonRegistrarse: UIButton!
    @IBOutlet weak var Confirmar: UIButton!
    
    
    var cambiaElProgresoDelRegistro = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        updateUI()
        
        self.Usuario.delegate = self
        self.Correo.delegate = self
        self.Contraseña.delegate = self
        self.Confirmar.alpha = 0
    }
    
//    override func viewDidAppear(_ animated: Bool) {
//        super.viewDidAppear(animated)
//        
//        if let user = Auth.auth().currentUser {
//            self.performSegue(withIdentifier: "EventosUserSegue", sender: self)
//        }
//    }
    
    @IBAction func botonRegistro(_ sender: UIButton) {
            Auth.auth().createUser(withEmail: Correo.text!, password: Contraseña.text!) { (user, error)  in
                if error == nil && user != nil
                {
                    print("Usuario creado")
                    
                    self.Aviso.text = "User created successfully."
                    self.BotonRegistrarse.alpha = 0
                    self.Confirmar.alpha = 1
                    
            let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                changeRequest?.displayName = self.Usuario.text!
                }else{
                    self.Aviso.textColor = UIColor.red
                    self.Aviso.text = ("\(error!.localizedDescription)")
                }
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        Usuario.resignFirstResponder()
        Correo.resignFirstResponder()
        Contraseña.resignFirstResponder()
        return (true)
    }
    
    func updateUI()
    {
        vistaDeCategorias.isHidden = false
        vistaDelRegistroFinal.isHidden = true
        
        progresoDelRegistro.setProgress( Float(cambiaElProgresoDelRegistro), animated: true)
        
        if vistaDeCategorias.isHidden == false
        {
            let totalProgreso = cambiaElProgresoDelRegistro
            progresoDelRegistro.setProgress(Float(totalProgreso), animated: true)
            categorias.text = " 〰️Categorias〰️ "
            stack1DeCat.isHidden = false
            cat1.text = "Arte y Cultura 🎭"
            switch1.isOn = false
            stack2DeCat.isHidden = false
            cat2.text = "Ciencia ⚗️"
            switch2.isOn = false
            stack3DeCat.isHidden = false
            cat3.text = "Educación 👨‍🏫"
            switch3.isOn = false
            stack4DeCat.isHidden = false
            cat4.text = "Tecnología 🤖"
            switch4.isOn = false
            stack5DeCat.isHidden = false
            cat5.text = "Deporte 🏃‍♂️"
            switch5.isOn = false
            stack6DeCat.isHidden = false
            cat6.text = "Social 👥"
            switch6.isOn = false
            
            
            
        }
        
        
    }
    
    @IBAction func pasa(_ sender: Any) {
        if vistaDeCategorias.isHidden == false{
        vistaDeCategorias.isHidden = true
            if vistaDeCategorias.isHidden == true
            {
        vistaDelRegistroFinal.isHidden = false
        progresoDelRegistro.setProgress(Float(cambiaElProgresoDelRegistro + 1), animated: true)
        }
    }
    }
}
