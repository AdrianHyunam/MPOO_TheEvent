//
//  EventosDelUsuarioViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import Firebase

class EventosDelUsuarioViewController: UIViewController,UITextFieldDelegate{
    
    //Outlets para quitar
    @IBOutlet weak var Email: UITextField!
    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var Logo: UIImageView!
    @IBOutlet weak var Texto: UILabel!
    @IBOutlet weak var BotonInicio: UIButton!
    @IBOutlet weak var BotonRegistro: UIButton!
    
    //Outlets para poner
    @IBOutlet weak var BotonCrear: UIButton!
    @IBOutlet weak var BotonCerrar: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.Email.delegate = self
        self.Password.delegate = self
        
        self.Email.alpha = 1
        self.Password.alpha = 1
        self.Logo.alpha = 1
        self.Texto.alpha = 1
        self.BotonInicio.alpha = 1
        self.BotonRegistro.alpha = 1
        
        self.BotonCrear.alpha = 0
        self.BotonCerrar.alpha = 0
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if let user = Auth.auth().currentUser {
            self.Email.alpha = 0
            self.Password.alpha = 0
            self.Logo.alpha = 0
            self.Texto.alpha = 0
            self.BotonInicio.alpha = 0
            self.BotonRegistro.alpha = 0
            
            self.BotonCrear.alpha = 1
            self.BotonCerrar.alpha = 1
        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
//Ocultar con tocar pantalla
   override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
//Ocultar con enter
   func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        Email.resignFirstResponder()
        Password.resignFirstResponder()
    return (true)
    }
    
    @IBAction func unwindEventosSegue(segue: UIStoryboardSegue){
    }
    
    //funcion iniciar sesion
    @IBAction func IniciarSesion() {
        guard let email = Email.text else { return }
        guard let pass = Password.text else { return }
        
        Auth.auth().signIn(withEmail: email, password: pass) { user, error in
            if error == nil && user != nil {
                self.dismiss(animated: false, completion: nil)
                self.Email.alpha = 0
                self.Password.alpha = 0
                self.Logo.alpha = 0
                self.Texto.alpha = 0
                self.BotonInicio.alpha = 0
                self.BotonRegistro.alpha = 0
                
                self.BotonCrear.alpha = 1
                self.BotonCerrar.alpha = 1
                
            } else {
                print("Error logging in: \(error!.localizedDescription)")
            }
        }
    }
    
    //funcion cerrar sesion
    
    @IBAction func BotonCerrar(_ sender:Any) {
        try! Auth.auth().signOut()
        self.dismiss(animated: false, completion: nil)
        
        self.Email.alpha = 1
        self.Password.alpha = 1
        self.Logo.alpha = 1
        self.Texto.alpha = 1
        self.BotonInicio.alpha = 1
        self.BotonRegistro.alpha = 1
        
        self.BotonCrear.alpha = 0
        self.BotonCerrar.alpha = 0

    }
    
 }
