//
//  AddEventoViewController.swift
//  TheEventAPP
//
//  Created by Macbook on 11/29/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import Firebase

class AddEventoViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var nombre: UITextField!
    @IBOutlet weak var fecha: UITextField!
    @IBOutlet weak var hora: UITextField!
    @IBOutlet weak var descripcion: UITextView!
    @IBOutlet weak var direccion: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.nombre.delegate = self
        self.fecha.delegate = self
        self.hora.delegate = self
        self.descripcion.delegate = self as? UITextViewDelegate
        self.direccion.delegate = self
    }
    
    @IBAction func registrarEvento(_ sender: UIButton) {
        let nombreEvento = nombre.text
        let fechaEvento = fecha.text
        let horaEvento = hora.text
        let descripcionEvento = descripcion.text
        let direccionEvento = direccion.text
        
        Firestore.firestore().collection("eventos").addDocument(data: ["nombre": nombreEvento, "fecha": fechaEvento, "hora": horaEvento, "descripcion": descripcionEvento, "direccion": direccionEvento]) {
            (error) in
            if let error = error {
                debugPrint(error)
            }else{
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        nombre.resignFirstResponder()
        fecha.resignFirstResponder()
        hora.resignFirstResponder()
        descripcion.resignFirstResponder()
        direccion.resignFirstResponder()
        return (true)
    }
}
