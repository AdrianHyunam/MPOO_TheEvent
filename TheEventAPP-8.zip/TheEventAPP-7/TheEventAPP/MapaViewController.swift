//
//  MapaViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//


import UIKit
import MapKit
import CoreLocation

class MapaViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    
    @IBOutlet weak var mapita: MKMapView!
    
    @IBOutlet weak var Tipos: UISegmentedControl!
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapita.delegate = self
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        
        locationManager.startUpdatingLocation()
        mapita.showsUserLocation = true
        
        Tipos.addTarget(self, action: #selector(cambiarMapas), for: .valueChanged)
    }
    
    @IBAction func cambiarMapas( segmentedControl: UISegmentedControl) {
        switch(segmentedControl.selectedSegmentIndex){
        case 0:
            mapita.mapType = .standard
        case 1:
            mapita.mapType = .satellite
        case 2:
            mapita.mapType = .hybrid
        default:
            mapita.mapType = .standard
        }
    }
    
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let region = MKCoordinateRegion(center: mapita.userLocation.coordinate , span: MKCoordinateSpan(latitudeDelta: 0.0009, longitudeDelta: 0.0009) )
        
        mapita.setRegion(region, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations.first)
    }
}

