//
//  EventoViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import Firebase

class EventosMasRecientesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
   
    @IBOutlet weak var tablita: UITableView!
    
    private var listaEventos = [eventos]()
    var EventosRef : CollectionReference!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tablita.delegate = self
        tablita.dataSource = self
        
        let evento = eventos(nombreEvento: "Opera", fechaInicio: "Hoy", fechaFin: "mañana", horaEvento: "8:10", descripcionEvento: "Hola", direccionEvento: "Aqui mero")
        listaEventos.append(evento)
        
        EventosRef = Firestore.firestore().collection("eventos")
        
    }
    
    /*    func numberOfSections(in tableView: UITableView) -> Int {
     return 2
     }*/
    
    override func viewWillAppear(_ animated: Bool) {
        EventosRef.addSnapshotListener {(snapshot, error) in debugPrint(error)
            self.EventosRef.getDocuments { (snapshot, error) in
                if let error = error{
                    debugPrint(error)
                }else{
                    
                    self.listaEventos.removeAll()
                    for document in (snapshot?.documents)!{
                        
                        print(document.data())
                        
                        
                        let data = document.data()
                        let nombre = data["nombre"] as! String
                        let fechaI = data["fechaInicio"] as! String
                        let fechaF = data["fechaFin"] as! String
                        let hora = data["hora"] as! String
                        let descripcion = data["descripcion"] as! String
                        let direccion = data["direccion"] as! String
                        
                        
                        let documentId = document.documentID
                        
                        let nuevoEvento = eventos(nombreEvento: nombre, fechaInicio: fechaI, fechaFin: fechaF, horaEvento: hora, descripcionEvento: descripcion, direccionEvento: direccion)
                        self.listaEventos.append(nuevoEvento)
                    }
                    self.tablita.reloadData()
                }
            }
        }
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaEventos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cel = tablita.dequeueReusableCell(withIdentifier: "evento", for: indexPath) as? ClaseEventoCell{
            cel.backgroundColor = UIColor.orange.withAlphaComponent(0.3)
            cel.textLabel?.text = "Soy la celda mas verguera la numero \(indexPath.row)"
            cel.layer.borderWidth = 1
            cel.layer.cornerRadius = 10
            cel.imageView?.layer.cornerRadius = 20
            
            cel.configureCell(eventos: listaEventos[indexPath.row])
            return cel
        }else{
            return UITableViewCell()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "info"{
            
            let indexPath = tablita.indexPathForSelectedRow
            
            let destino = segue.destination as! ViewController
            destino.vieneDeAtras = listaEventos[(indexPath?.row)!]
        }
    }
    
}

