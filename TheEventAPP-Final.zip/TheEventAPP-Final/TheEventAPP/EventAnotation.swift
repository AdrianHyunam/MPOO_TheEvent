//
//  EventAnotation.swift
//  TheEventAPP
//
//  Created by iMac 3 on 12/5/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import MapKit

class EventAnotation : MKPointAnnotation{
    var imageURL :String!
}
