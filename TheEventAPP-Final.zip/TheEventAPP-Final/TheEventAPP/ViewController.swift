//
//  ViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 24/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController, MKMapViewDelegate {

    @IBOutlet weak var nomEvento: UILabel!
    @IBOutlet weak var fehcaInicio: UILabel!
    @IBOutlet weak var fechaFinal: UILabel!
    @IBOutlet weak var descripcion: UITextView!
    @IBOutlet weak var categoria: UILabel!
    @IBOutlet weak var solidMap: MKMapView!
    
    var vieneDeAtras : eventos!
    var direccion: String!
    var geocoder = CLGeocoder()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nomEvento.text = vieneDeAtras.nombreEvento
        fehcaInicio.text = vieneDeAtras.fechaInicio
        fechaFinal.text = vieneDeAtras.fechaFin
        descripcion.text = vieneDeAtras.descripcionEvento
        categoria.text = vieneDeAtras.horaEvento
        direccion = vieneDeAtras.direccionEvento
       
    }
    override func viewWillAppear(_ animated: Bool) {
        geocoder.geocodeAddressString(vieneDeAtras.direccionEvento, completionHandler: {(placemarks, error) -> Void in
            if((error) != nil){
                print("Error", error ?? "")
            }
            if let placemark = placemarks?.first {
                let coordinates:CLLocationCoordinate2D = placemark.location!.coordinate
                print("Lat: \(coordinates.latitude) -- Long: \(coordinates.longitude)")
                let annotation = EventAnotation()
                annotation.coordinate = CLLocationCoordinate2D(latitude: coordinates.latitude, longitude: coordinates.longitude)
                annotation.title = self.vieneDeAtras.nombreEvento
                annotation.imageURL = "Final.png"
                self.solidMap.addAnnotation(annotation)
                
                let region = MKCoordinateRegion(center: annotation.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.0009, longitudeDelta: 0.0009))
                self.solidMap.setRegion(region, animated: true)
            }
        })
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ParaMapa"{
            
            let destino = segue.destination as! MapaViewController
            destino.Direccion = direccion
            destino.NombreEvento = vieneDeAtras.nombreEvento
            
        }
    }
    func mapView( mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if annotation is MKUserLocation{
            return nil
        }
        
        var EventAnotationView = solidMap.dequeueReusableAnnotationView(withIdentifier: "EventAnotationView")
        if EventAnotationView == nil{
            EventAnotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "EventAnotationView")
            
            EventAnotationView?.canShowCallout = true
        }else{
            EventAnotationView?.annotation = annotation
        }
        if let EventAnotation = annotation as? EventAnotation{
            
            EventAnotationView?.image = UIImage(named: EventAnotation.imageURL)
        }
        return EventAnotationView
    }
}

