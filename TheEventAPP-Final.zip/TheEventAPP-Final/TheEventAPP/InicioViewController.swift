//
//  InicioViewController.swift
//  TheEventAPP
//
//  Created by Macbook on 11/28/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class InicioViewController: UITabBarController {
    @IBOutlet weak var barControler: UITabBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        barControler.unselectedItemTintColor = UIColor.orange.withAlphaComponent(0.6)
    }

}
