//
//  MapaViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//


import UIKit
import MapKit
import CoreLocation

class MapaViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    
    @IBOutlet weak var mapita: MKMapView!
    
    @IBOutlet weak var Tipos: UISegmentedControl!
    private var locationManager = CLLocationManager()
    let geocoder = CLGeocoder()
    var Direccion:String!
    var NombreEvento:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapita.delegate = self
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        
        locationManager.startUpdatingLocation()
        mapita.showsUserLocation = true
        
        Tipos.addTarget(self, action: #selector(cambiarMapas), for: .valueChanged)
        
        
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        geocoder.geocodeAddressString(Direccion, completionHandler: {(placemarks, error) -> Void in
            if((error) != nil){
                print("Error", error ?? "")
            }
            if let placemark = placemarks?.first {
                let coordinates:CLLocationCoordinate2D = placemark.location!.coordinate
                print("Lat: \(coordinates.latitude) -- Long: \(coordinates.longitude)")
                let annotation = EventAnotation()
                annotation.coordinate = CLLocationCoordinate2D(latitude: coordinates.latitude, longitude: coordinates.longitude)
                annotation.title = self.NombreEvento
                annotation.imageURL = "Final.png"
                self.mapita.addAnnotation(annotation)
                
                let region = MKCoordinateRegion(center: (annotation.coordinate), span: MKCoordinateSpan(latitudeDelta: 0.0009, longitudeDelta: 0.0009))
                
                self.mapita.setRegion(region, animated: true)
                
                
            }
        })
    }
    
    
    
    
    @IBAction func cambiarMapas( segmentedControl: UISegmentedControl) {
        switch(segmentedControl.selectedSegmentIndex){
        case 0:
            mapita.mapType = .standard
        case 1:
            mapita.mapType = .satellite
        case 2:
            mapita.mapType = .hybrid
        default:
            mapita.mapType = .standard
        }
    }
    func mapView( mapView: MKMapView, renderFor overlay: MKOverlay) -> MKOverlayRenderer{
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.orange
        renderer.lineWidth  = 4.0
        return renderer
        
    }
    
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations.first)
    }
    
    func mapView( mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if annotation is MKUserLocation{
            return nil
        }
        
        var EventAnotationView = mapita.dequeueReusableAnnotationView(withIdentifier: "EventAnotationView")
        if EventAnotationView == nil{
            EventAnotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "EventAnotationView")
            
            EventAnotationView?.canShowCallout = true
        }else{
            EventAnotationView?.annotation = annotation
        }
        if let EventAnotation = annotation as? EventAnotation{
            
            EventAnotationView?.image = UIImage(named: EventAnotation.imageURL)
        }
        return EventAnotationView
    }
    
    
    
    
}

