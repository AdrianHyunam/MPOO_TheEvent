//
//  evento.swift
//  TheEventAPP
//
//  Created by Macbook on 12/3/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import Foundation

struct eventos{
    var nombreEvento: String
    var fechaInicio: String
    var fechaFin: String
    var horaEvento : String
    var descripcionEvento : String
    var direccionEvento : String
}
