//
//  Evento.swift
//  TheEventAPP
//
//  Created by Macbook on 11/15/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import Foundation
import UIKit

class Evento {
    let nombre: String
    let imagen: String
    let fecha: [String]
    
    init(nombre: String, imagen: String, fecha: [String])
    {
        self.nombre = nombre
        self.imagen = imagen
        self.fecha = fecha
    }
}
