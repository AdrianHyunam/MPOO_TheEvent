//
//  EventoViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class EventoViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    @IBOutlet weak var firstCollectionView: UICollectionView!
    @IBOutlet weak var secondCollectionView: UICollectionView!
    @IBOutlet weak var tercerCollectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        secondCollectionView.delegate = self
        firstCollectionView.delegate = self
        tercerCollectionView.delegate = self
        
        // Do any additional setup after loading the view.
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

    
        if collectionView.tag == 1
        {
           let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cat1", for: indexPath) as! EventoCollectionViewCell
            cell.backgroundColor = UIColor.red
            cell.num.text = "\(indexPath.item)"
            
            return cell
        }
        
        
        if collectionView.tag == 2
        {
        
           let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cat2", for: indexPath) as! EventoCollectionViewCell
            cell.backgroundColor = UIColor.blue
            
            return cell
        }
        
        if collectionView.tag == 3
        {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cat3", for: indexPath) as! EventoCollectionViewCell
            cell.backgroundColor = UIColor.green
            
            return cell
        }
        if collectionView.tag == 4
        {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cat4", for: indexPath) as! EventoCollectionViewCell
            cell.backgroundColor = UIColor.red
            
            return cell
        }
        if collectionView.tag == 5
        {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cat5", for: indexPath) as! EventoCollectionViewCell
            cell.backgroundColor = UIColor.blue
            
            return cell
        }
        if collectionView.tag == 6
        {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cat6", for: indexPath) as! EventoCollectionViewCell
            cell.backgroundColor = UIColor.green
            
            return cell
        }
        if collectionView.tag == 7
        {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cat7", for: indexPath) as! EventoCollectionViewCell
            cell.backgroundColor = UIColor.red
            
            return cell
        }
        if collectionView.tag == 8
        {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cat8", for: indexPath) as! EventoCollectionViewCell
            cell.backgroundColor = UIColor.blue
            
            return cell
        }

            
        else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cat0", for: indexPath) as! EventoCollectionViewCell
            cell.backgroundColor = UIColor.red
            cell.num.text = "\(indexPath.item)"
            
            return cell
        }

    }
  
    
}
    

