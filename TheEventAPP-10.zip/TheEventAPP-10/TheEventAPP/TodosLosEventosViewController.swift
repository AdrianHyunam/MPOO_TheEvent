//
//  TodosLosEventosViewController.swift
//  TheEventAPP
//
//  Created by Macbook on 11/22/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import Firebase

class TodosLosEventosViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tablaDeTodos: UITableView!
    @IBOutlet weak var Filtrar: UIButton!
    @IBOutlet weak var StackCate: UIStackView!
    @IBOutlet weak var StackTodos: UIStackView!
    
    
    @IBOutlet weak var Swit1: UISwitch!
    @IBOutlet weak var Swit2: UISwitch!
    @IBOutlet weak var Swit3: UISwitch!
    @IBOutlet weak var Swit4: UISwitch!
    @IBOutlet weak var Swit5: UISwitch!
    @IBOutlet weak var Swit6: UISwitch!
    
    
    private var listaEventos = [eventos]()
    var EventosRef : CollectionReference!
    var Eventos1Ref : CollectionReference!
    var Eventos2Ref : CollectionReference!
    var Eventos3Ref : CollectionReference!
    var Eventos4Ref : CollectionReference!
    var Eventos5Ref : CollectionReference!
    var Eventos6Ref : CollectionReference!
    var UsuariosRef : CollectionReference!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        StackTodos.alpha = 1
        StackCate.alpha = 0
        Filtrar.alpha = 1
        
        tablaDeTodos.delegate = self
        tablaDeTodos.dataSource = self
        // Do any additional setup after loading the view.
        let evento = eventos(nombreEvento: "Opera", fechaEvento: "Hoy", horaEvento: "8:10", descripcionEvento: "Hola", direccionEvento: "Aqui mero")
        listaEventos.append(evento)
        
        EventosRef = Firestore.firestore().collection("eventos")
        Eventos1Ref = Firestore.firestore().collection("Arte y Cultura 🎭")
        Eventos2Ref = Firestore.firestore().collection("Ciencia ⚗️")
        Eventos3Ref = Firestore.firestore().collection("Educación 👨‍🏫")
        Eventos4Ref = Firestore.firestore().collection("Tecnología 🤖")
        Eventos5Ref = Firestore.firestore().collection("Deporte 🏃‍♂️")
        Eventos6Ref = Firestore.firestore().collection("Social 👥")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        EventosRef.addSnapshotListener {(snapshot, error) in debugPrint(error)
            self.EventosRef.getDocuments { (snapshot, error) in
                if let error = error{
                    debugPrint(error)
                }else{
                    
                    self.listaEventos.removeAll()
                    for document in (snapshot?.documents)!{
                        
                        print(document.data())
                        
                        
                        let data = document.data()
                        let nombre = data["nombre"] as! String
                        let fecha = data["fecha"] as! String
                        let hora = data["hora"] as! String
                        let descripcion = data["descripcion"] as! String
                        let direccion = data["direccion"] as! String
                        
                        
                        let documentId = document.documentID
                        
                        let nuevoEvento = eventos(nombreEvento: nombre, fechaEvento: fecha, horaEvento: hora, descripcionEvento: descripcion, direccionEvento: direccion)
                        self.listaEventos.append(nuevoEvento)
                    }
                    self.tablaDeTodos.reloadData()
                }
            }
        }
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaEventos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            if let cel = tablaDeTodos.dequeueReusableCell(withIdentifier: "eventos", for: indexPath) as? ClaseEventoCell
            {
            cel.backgroundColor = UIColor.orange.withAlphaComponent(0.4)
            cel.textLabel?.text = "Soy la celda mas verguera la numero \(indexPath.row) neta"
            cel.layer.borderWidth = 1
            cel.layer.cornerRadius = 10
            cel.imageView?.layer.cornerRadius = 20
            cel.imageView?.layer.borderWidth = 2
        
            cel.configureCell2(eventos: listaEventos[indexPath.row])
            return cel
            }else{
                return UITableViewCell()
        }
    }
    
    
    @IBAction func bontonFiltrar(_ sender: UIButton) {
        StackTodos.alpha = 0
        StackCate.alpha = 1
        Filtrar.alpha = 0
    }
    
    @IBAction func botonConfirmar(_ sender: UIButton) {
        StackTodos.alpha = 1
        StackCate.alpha = 0
        Filtrar.alpha = 1
        
        self.listaEventos.removeAll()
        if Swit1.isOn == true
        {
            Eventos1Ref.addSnapshotListener {(snapshot, error) in debugPrint(error)
                self.Eventos1Ref.getDocuments { (snapshot, error) in
                    if let error = error{
                        debugPrint(error)
                    }else{
                        for document in (snapshot?.documents)!{
                            self.listaEventos.removeAll()
                            print(document.data())
                            
                            
                            let data = document.data()
                            let nombre = data["nombre"] as! String
                            let fecha = data["fecha"] as! String
                            let hora = data["hora"] as! String
                            let descripcion = data["descripcion"] as! String
                            let direccion = data["direccion"] as! String
                            
                            
                            let documentId = document.documentID
                            
                            let nuevoEvento = eventos(nombreEvento: nombre, fechaEvento: fecha, horaEvento: hora, descripcionEvento: descripcion, direccionEvento: direccion)
                            self.listaEventos.append(nuevoEvento)
                        }
                        self.tablaDeTodos.reloadData()
                    }
                }
            }
            
        }
        if Swit2.isOn == true
        {
            Eventos2Ref.addSnapshotListener {(snapshot, error) in debugPrint(error)
                self.Eventos2Ref.getDocuments { (snapshot, error) in
                    if let error = error{
                        debugPrint(error)
                    }else{
                        
                        
                        for document in (snapshot?.documents)!{
                            
                            print(document.data())
                            
                            
                            let data = document.data()
                            let nombre = data["nombre"] as! String
                            let fecha = data["fecha"] as! String
                            let hora = data["hora"] as! String
                            let descripcion = data["descripcion"] as! String
                            let direccion = data["direccion"] as! String
                            
                            
                            let documentId = document.documentID
                            
                            let nuevoEvento = eventos(nombreEvento: nombre, fechaEvento: fecha, horaEvento: hora, descripcionEvento: descripcion, direccionEvento: direccion)
                            self.listaEventos.append(nuevoEvento)
                        }
                        self.tablaDeTodos.reloadData()
                    }
                }
            }
            
        }
        if Swit3.isOn == true
        {
            Eventos3Ref.addSnapshotListener {(snapshot, error) in debugPrint(error)
                self.Eventos3Ref.getDocuments { (snapshot, error) in
                    if let error = error{
                        debugPrint(error)
                    }else{
                        
                        
                        for document in (snapshot?.documents)!{
                            
                            print(document.data())
                            
                            
                            let data = document.data()
                            let nombre = data["nombre"] as! String
                            let fecha = data["fecha"] as! String
                            let hora = data["hora"] as! String
                            let descripcion = data["descripcion"] as! String
                            let direccion = data["direccion"] as! String
                            
                            
                            let documentId = document.documentID
                            
                            let nuevoEvento = eventos(nombreEvento: nombre, fechaEvento: fecha, horaEvento: hora, descripcionEvento: descripcion, direccionEvento: direccion)
                            self.listaEventos.append(nuevoEvento)
                        }
                        self.tablaDeTodos.reloadData()
                    }
                }
            }
            
        }
        if Swit4.isOn == true
        {
            Eventos4Ref.addSnapshotListener {(snapshot, error) in debugPrint(error)
                self.Eventos4Ref.getDocuments { (snapshot, error) in
                    if let error = error{
                        debugPrint(error)
                    }else{
                        
                        
                        for document in (snapshot?.documents)!{
                            
                            print(document.data())
                            
                            
                            let data = document.data()
                            let nombre = data["nombre"] as! String
                            let fecha = data["fecha"] as! String
                            let hora = data["hora"] as! String
                            let descripcion = data["descripcion"] as! String
                            let direccion = data["direccion"] as! String
                            
                            
                            let documentId = document.documentID
                            
                            let nuevoEvento = eventos(nombreEvento: nombre, fechaEvento: fecha, horaEvento: hora, descripcionEvento: descripcion, direccionEvento: direccion)
                            self.listaEventos.append(nuevoEvento)
                        }
                        self.tablaDeTodos.reloadData()
                    }
                }
            }
            
        }
        if Swit5.isOn == true
        {
            Eventos5Ref.addSnapshotListener {(snapshot, error) in debugPrint(error)
                self.Eventos5Ref.getDocuments { (snapshot, error) in
                    if let error = error{
                        debugPrint(error)
                    }else{
                        
                        
                        for document in (snapshot?.documents)!{
                            
                            print(document.data())
                            
                            
                            let data = document.data()
                            let nombre = data["nombre"] as! String
                            let fecha = data["fecha"] as! String
                            let hora = data["hora"] as! String
                            let descripcion = data["descripcion"] as! String
                            let direccion = data["direccion"] as! String
                            
                            
                            let documentId = document.documentID
                            
                            let nuevoEvento = eventos(nombreEvento: nombre, fechaEvento: fecha, horaEvento: hora, descripcionEvento: descripcion, direccionEvento: direccion)
                            self.listaEventos.append(nuevoEvento)
                        }
                        self.tablaDeTodos.reloadData()
                    }
                }
            }
            
        }
        if Swit6.isOn == true
        {
            Eventos6Ref.addSnapshotListener {(snapshot, error) in debugPrint(error)
                self.Eventos6Ref.getDocuments { (snapshot, error) in
                    if let error = error{
                        debugPrint(error)
                    }else{
                        
                        
                        for document in (snapshot?.documents)!{
                            
                            print(document.data())
                            
                            
                            let data = document.data()
                            let nombre = data["nombre"] as! String
                            let fecha = data["fecha"] as! String
                            let hora = data["hora"] as! String
                            let descripcion = data["descripcion"] as! String
                            let direccion = data["direccion"] as! String
                            
                            
                            let documentId = document.documentID
                            
                            let nuevoEvento = eventos(nombreEvento: nombre, fechaEvento: fecha, horaEvento: hora, descripcionEvento: descripcion, direccionEvento: direccion)
                            self.listaEventos.append(nuevoEvento)
                        }
                        self.tablaDeTodos.reloadData()
                    }
                }
            }
            
        }
        
        if Swit1.isOn == false && Swit2.isOn == false && Swit3.isOn == false && Swit4.isOn == false && Swit5.isOn == false && Swit6.isOn == false
        {
            EventosRef.addSnapshotListener {(snapshot, error) in debugPrint(error)
                self.EventosRef.getDocuments { (snapshot, error) in
                    if let error = error{
                        debugPrint(error)
                    }else{
                        for document in (snapshot?.documents)!{
                            
                            print(document.data())
                            
                            
                            let data = document.data()
                            let nombre = data["nombre"] as! String
                            let fecha = data["fecha"] as! String
                            let hora = data["hora"] as! String
                            let descripcion = data["descripcion"] as! String
                            let direccion = data["direccion"] as! String
                            
                            
                            let documentId = document.documentID
                            
                            let nuevoEvento = eventos(nombreEvento: nombre, fechaEvento: fecha, horaEvento: hora, descripcionEvento: descripcion, direccionEvento: direccion)
                            self.listaEventos.append(nuevoEvento)
                        }
                        self.tablaDeTodos.reloadData()
                    }
                }
            }
            
        }
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "info2"{
            
            let indexPath = tablaDeTodos.indexPathForSelectedRow
            
            let destino = segue.destination as! ViewController
            destino.vieneDeAtras = listaEventos[(indexPath?.row)!]
        }
    }

}
