//
//  EventosDelUsuarioViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import Firebase

class EventosDelUsuarioViewController: UIViewController,UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource{
    
    //Outlets para quitar
    @IBOutlet weak var Email: UITextField!
    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var Logo: UIImageView!
    @IBOutlet weak var Texto: UILabel!
    @IBOutlet weak var BotonInicio: UIButton!
    @IBOutlet weak var BotonRegistro: UIButton!
    @IBOutlet weak var avisoDeError: UILabel!
    
    //Outlets para poner
    @IBOutlet weak var BotonCrear: UIButton!
    @IBOutlet weak var BotonCerrar: UIButton!
    @IBOutlet weak var imagenDelUsuario: UIImageView!
    @IBOutlet weak var tablaDelUsuario: UITableView!
    @IBOutlet weak var textoDelUsuario: UILabel!
    @IBOutlet weak var stackDelUsuario: UIStackView!
    
    private var listaUsuarios = [usuarios]()
    private var listaEventos = [eventos]()
    
    var correoGlo = [String]()
    var EventosRef : CollectionReference!
//    var Eventos1Ref : CollectionReference!
//    var Eventos2Ref : CollectionReference!
//    var Eventos3Ref : CollectionReference!
//    var Eventos4Ref : CollectionReference!
//    var Eventos5Ref : CollectionReference!
//    var Eventos6Ref : CollectionReference!
    var UsuariosRef : CollectionReference!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.Email.delegate = self
        self.Password.delegate = self
        
        self.Email.alpha = 1
        self.Password.alpha = 1
        self.Logo.alpha = 1
        self.Texto.alpha = 1
        self.BotonInicio.alpha = 1
        self.BotonRegistro.alpha = 1
        self.avisoDeError.alpha = 1
        
        self.stackDelUsuario.alpha = 0
        self.imagenDelUsuario.layer.borderWidth = 1
        self.imagenDelUsuario.layer.cornerRadius = imagenDelUsuario.bounds.height/50
        self.BotonCrear.alpha = 0
        self.BotonCerrar.alpha = 0
        
        let evento = eventos(nombreEvento: "Opera", fechaEvento: "Hoy", horaEvento: "8:10", descripcionEvento: "Hola", direccionEvento: "Aqui mero")
        listaEventos.append(evento)
        
        EventosRef = Firestore.firestore().collection("eventos")
        UsuariosRef = Firestore.firestore().collection("PerfilesDeUsuarios")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if let user = Auth.auth().currentUser {
            self.Email.alpha = 0
            self.Password.alpha = 0
            self.Logo.alpha = 0
            self.Texto.alpha = 0
            self.BotonInicio.alpha = 0
            self.BotonRegistro.alpha = 0
            self.avisoDeError.alpha = 0
            
            self.stackDelUsuario.alpha = 1
            self.BotonCrear.alpha = 1
            self.BotonCerrar.alpha = 1
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        UsuariosRef.addSnapshotListener {(snapshot, error) in debugPrint(error)
            self.UsuariosRef.getDocuments { (snapshot, error) in
                if let error = error{
                    debugPrint(error)
                }else{
                    
                    self.listaUsuarios.removeAll()
                    for document in (snapshot?.documents)!{
                        
                        print(document.data())
                        
                        
                        let data = document.data()
                        let nombre = data["Nombre"] as! String
                        let correo = data["Correo"] as! String
                        let contraseña = data["Contraseña"] as! String
                        
                        let documentId = document.documentID
                        
                        let nuevoUsuario = usuarios(nombreUsuario: nombre, correoUsuario: correo, contraseña: contraseña)
                        self.listaUsuarios.append(nuevoUsuario)
                    }
                    self.tablaDelUsuario.reloadData()
                }
            }
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
//Ocultar con tocar pantalla
   override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
//Ocultar con enter
   func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        Email.resignFirstResponder()
        Password.resignFirstResponder()
    return (true)
    }
    
    @IBAction func unwindEventosSegue(segue: UIStoryboardSegue){
    }
    
    //funcion iniciar sesion
    @IBAction func IniciarSesion() {
        guard let email = Email.text else { return }
        guard let pass = Password.text else { return }
        
        Auth.auth().signIn(withEmail: email, password: pass) { user, error in
            if error == nil && user != nil {
                
                self.dismiss(animated: false, completion: nil)
                self.Email.alpha = 0
                self.Password.alpha = 0
                self.Logo.alpha = 0
                self.Texto.alpha = 0
                self.BotonInicio.alpha = 0
                self.BotonRegistro.alpha = 0
                self.avisoDeError.alpha = 0
                
                self.stackDelUsuario.alpha = 1
              
                self.BotonCrear.alpha = 1
                self.BotonCerrar.alpha = 1
                
            }else {
                print("Error logging in: \(error!.localizedDescription)")
                self.avisoDeError.text = "\(error!.localizedDescription)"
            }
        }
        
    }
    
    //funcion cerrar sesion
    
    @IBAction func BotonCerrar(_ sender:Any) {
        try! Auth.auth().signOut()
        self.dismiss(animated: false, completion: nil)
        
        self.Email.alpha = 1
        self.Password.alpha = 1
        self.Logo.alpha = 1
        self.Texto.alpha = 1
        self.BotonInicio.alpha = 1
        self.BotonRegistro.alpha = 1
        
        self.stackDelUsuario.alpha = 0
        self.BotonCrear.alpha = 0
        self.BotonCerrar.alpha = 0

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaEventos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          if let cel = tablaDelUsuario.dequeueReusableCell(withIdentifier: "userCat", for: indexPath) as? ClaseEventoCell
          {
            cel.backgroundColor = UIColor.orange.withAlphaComponent(0.5)
            cel.textLabel?.text = "Soy la celda mas verguera la numero \(indexPath.row) neta"
            cel.layer.borderWidth = 1
            cel.layer.cornerRadius = 10
            cel.imageView?.layer.cornerRadius = 20
            cel.imageView?.layer.borderWidth = 2
        
        cel.configureCell3(eventos: listaEventos[indexPath.row])
        return cel
    }else{
    return UITableViewCell()
    }
}

override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if segue.identifier == "info3"{
        
        let indexPath = tablaDelUsuario.indexPathForSelectedRow
        
        let destino = segue.destination as! ViewController
        destino.vieneDeAtras = listaEventos[(indexPath?.row)!]
    }
}

}
