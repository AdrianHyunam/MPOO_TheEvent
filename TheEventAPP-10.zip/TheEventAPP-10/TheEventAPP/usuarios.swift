//
//  usuarios.swift
//  TheEventAPP
//
//  Created by Macbook on 12/4/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import Foundation

struct usuarios{
    var nombreUsuario: String
    var correoUsuario: String
    var contraseña : String
}
