//
//  Titulo.swift
//  TheEventAPP
//
//  Created by Macbook on 11/28/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class Titulo: UINavigationItem {

}
