//
//  CoffeAnnotation.swift
//  TheEventAPP
//
//  Created by Macbook on 11/30/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//
import UIKit
import MapKit

class CoffeAnnotation : MKPointAnnotation{
    var imageURL :String!
}
