//
//  AddEventoViewController.swift
//  TheEventAPP
//
//  Created by Macbook on 11/29/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import Firebase

class AddEventoViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var nombre: UITextField!
    @IBOutlet weak var fecha: UITextField!
    @IBOutlet weak var fechaDeFin: UITextField!
    @IBOutlet weak var hora: UITextField!
    @IBOutlet weak var descripcion: UITextView!
    @IBOutlet weak var direccion: UITextField!
    
    @IBOutlet weak var progreso: UIProgressView!
    
    @IBOutlet weak var viewDeDatos: UIView!
    @IBOutlet weak var imagenDelEvento: UIImageView!
    @IBOutlet weak var sw1: UISwitch!
    @IBOutlet weak var sw2: UISwitch!
    @IBOutlet weak var sw3: UISwitch!
    @IBOutlet weak var sw4: UISwitch!
    @IBOutlet weak var sw5: UISwitch!
    @IBOutlet weak var sw6: UISwitch!
    @IBOutlet weak var viewDeDatos2: UIView!
    
    
    let progresoDelEvento = 0.1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.nombre.delegate = self
        self.fecha.delegate = self
        self.hora.delegate = self
        self.descripcion.delegate = self as? UITextViewDelegate
        self.direccion.delegate = self
        descripcion.clearsOnInsertion = true
    }
    
    @IBAction func registrarEvento(_ sender: UIButton) {
        let nombreEvento : String! = nombre.text
        let fechaEvento : String! = fecha.text
        let horaEvento : String! = hora.text
        let descripcionEvento : String! = descripcion.text
        let direccionEvento : String! = direccion.text
        let tiempo = FieldValue.serverTimestamp()
        
        
        Firestore.firestore().collection("eventos").addDocument(data: ["nombre": nombreEvento, "fecha": fechaEvento, "hora": horaEvento, "descripcion": descripcionEvento, "direccion": direccionEvento, "fechaCreado": tiempo]) {
            (error) in
            if let error = error {
                debugPrint(error)
            }
        }
        
        if sw1.isOn == true
        {
            Firestore.firestore().collection("Arte y Cultura 🎭").addDocument(data: ["nombre": nombreEvento, "fecha": fechaEvento, "hora": horaEvento, "descripcion": descripcionEvento, "direccion": direccionEvento, "fechaCreado": tiempo]) {
                (error) in
                if let error = error {
                    debugPrint(error)
                }else{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
        if sw2.isOn == true
        {
            Firestore.firestore().collection("Ciencia ⚗️").addDocument(data: ["nombre": nombreEvento, "fecha": fechaEvento, "hora": horaEvento, "descripcion": descripcionEvento, "direccion": direccionEvento, "fechaCreado": tiempo]) {
                (error) in
                if let error = error {
                    debugPrint(error)
                }else{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        
        }
        if sw3.isOn == true
        {
            Firestore.firestore().collection("Educación 👨‍🏫").addDocument(data: ["nombre": nombreEvento, "fecha": fechaEvento, "hora": horaEvento, "descripcion": descripcionEvento, "direccion": direccionEvento, "fechaCreado": tiempo]) {
                (error) in
                if let error = error {
                    debugPrint(error)
                }else{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
        if sw4.isOn == true
        {
            Firestore.firestore().collection("Tecnología 🤖").addDocument(data: ["nombre": nombreEvento, "fecha": fechaEvento, "hora": horaEvento, "descripcion": descripcionEvento, "direccion": direccionEvento, "fechaCreado": tiempo]) {
                (error) in
                if let error = error {
                    debugPrint(error)
                }else{
                    self.navigationController?.popViewController(animated: true)
                }
            }
            
        }
        if sw5.isOn == true
        {
            Firestore.firestore().collection("Deporte 🏃‍♂️").addDocument(data: ["nombre": nombreEvento, "fecha": fechaEvento, "hora": horaEvento, "descripcion": descripcionEvento, "direccion": direccionEvento, "fechaCreado": tiempo]) {
                (error) in
                if let error = error {
                    debugPrint(error)
                }else{
                    self.navigationController?.popViewController(animated: true)
                }
            }
            
        }
        if sw6.isOn == true
        {
            Firestore.firestore().collection("Social 👥").addDocument(data: ["nombre": nombreEvento, "fecha": fechaEvento, "hora": horaEvento, "descripcion": descripcionEvento, "direccion": direccionEvento, "fechaCreado": tiempo]) {
                (error) in
                if let error = error {
                    debugPrint(error)
                }else{
                    self.navigationController?.popViewController(animated: true)
                }
            }
            
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        nombre.resignFirstResponder()
        fecha.resignFirstResponder()
        hora.resignFirstResponder()
        descripcion.resignFirstResponder()
        direccion.resignFirstResponder()
        return (true)
    }
    
    @IBAction func pasa(_ sender: Any) {
        viewDeDatos.isHidden = true
        viewDeDatos2.isHidden = false
        if viewDeDatos2.isHidden == false
        {
            progreso.setProgress(Float(progresoDelEvento + 0.9), animated: true)
            viewDeDatos2.isHidden = true
            viewDeDatos.isHidden = false
        }
    }
    
}
