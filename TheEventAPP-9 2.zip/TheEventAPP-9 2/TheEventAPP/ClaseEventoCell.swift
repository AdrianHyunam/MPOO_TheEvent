//
//  ClaseEventoCell.swift
//  TheEventAPP
//
//  Created by Macbook on 12/3/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class ClaseEventoCell: UITableViewCell {

    @IBOutlet weak var Nombre: UILabel!
    @IBOutlet weak var Nombre2: UILabel!
    @IBOutlet weak var Nombre3: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    func configureCell(eventos: eventos){
        Nombre.text = eventos.nombreEvento
    }

    func configureCell2(eventos: eventos){
        Nombre2.text = eventos.nombreEvento
    }
    
    func configureCell3(eventos: eventos){
        Nombre3.text = eventos.nombreEvento
    }

}
