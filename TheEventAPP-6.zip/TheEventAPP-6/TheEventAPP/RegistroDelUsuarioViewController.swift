//
//  RegistroDelUsuarioViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import Firebase

class RegistroDelUsuarioViewController: UIViewController {
    
    
    @IBOutlet weak var Usuario: UITextField!
    @IBOutlet weak var Correo: UITextField!
    @IBOutlet weak var Contraseña: UITextField!
    @IBOutlet weak var Aviso: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

    }
    
    @IBAction func botonRegistro(_ sender: UIButton) {
            Auth.auth().createUser(withEmail: Correo.text!, password: Contraseña.text!) { (user, error)  in
                if error == nil && user != nil
                {
                    print("Usuario creado")
                    self.Aviso.text = "User created successfully."
                    
            let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                changeRequest?.displayName = self.Usuario.text!
                }else{
                    self.Aviso.textColor = UIColor.red
                    self.Aviso.text = ("\(error!.localizedDescription)")
                }
        }
    }
    
}
