//
//  RegistroDelUsuarioViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import Firebase

class RegistroDelUsuarioViewController: UIViewController, UITextFieldDelegate{
    
    @IBOutlet weak var progresoDelRegistro: UIProgressView!
    
    @IBOutlet weak var vistaDeCategorias: UIStackView!
    var catElegidas = [String]()
    @IBOutlet weak var categorias: UILabel!
    @IBOutlet weak var stack1DeCat: UIStackView!
    @IBOutlet weak var cat1: UILabel!
    @IBOutlet weak var switch1: UISwitch!
    @IBOutlet weak var stack2DeCat: UIStackView!
    @IBOutlet weak var cat2: UILabel!
    @IBOutlet weak var switch2: UISwitch!
    @IBOutlet weak var stack3DeCat: UIStackView!
    @IBOutlet weak var cat3: UILabel!
    @IBOutlet weak var switch3: UISwitch!
    @IBOutlet weak var stack4DeCat: UIStackView!
    @IBOutlet weak var cat4: UILabel!
    @IBOutlet weak var switch4: UISwitch!
    @IBOutlet weak var stack5DeCat: UIStackView!
    @IBOutlet weak var cat5: UILabel!
    @IBOutlet weak var switch5: UISwitch!
    @IBOutlet weak var stack6DeCat: UIStackView!
    @IBOutlet weak var cat6: UILabel!
    @IBOutlet weak var switch6: UISwitch!
    
    @IBOutlet weak var vistaDelRegistroFinal: UIStackView!
    @IBOutlet weak var Usuario: UITextField!
    @IBOutlet weak var Correo: UITextField!
    @IBOutlet weak var Contraseña: UITextField!
    @IBOutlet weak var Aviso: UILabel!
    
    @IBOutlet weak var Imagen: UIStackView!
    @IBOutlet weak var Foto: UIImageView!
    
    
    @IBOutlet weak var BotonRegistrarse: UIButton!
    @IBOutlet weak var Confirmar: UIButton!
    @IBOutlet weak var botonDeContinuar: UIButton!
    
    
    var cambiaElProgresoDelRegistro = 0.0
    var imagePicker: UIImagePickerController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        updateUI()
        
        self.Usuario.delegate = self
        self.Correo.delegate = self
        self.Contraseña.delegate = self
        self.Confirmar.alpha = 0
        
        let imageTap = UITapGestureRecognizer(target: self, action: #selector(openImagePicker))
        Foto.isUserInteractionEnabled = true
        Foto.addGestureRecognizer(imageTap)
        Foto.layer.cornerRadius = 50
        Foto.layer.borderWidth = 0.1
        Foto.clipsToBounds = true
        
        imagePicker = UIImagePickerController()
        imagePicker.allowsEditing = true
        imagePicker.sourceType = .photoLibrary
        imagePicker.delegate = self
    }
    
    @objc func openImagePicker(_ sender:Any) {
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    
    @IBAction func botonRegistro(_ sender: UIButton) {
            Auth.auth().createUser(withEmail: Correo.text!, password: Contraseña.text!) { (user, error)  in
                if error == nil && user != nil
                {
                    print("Usuario creado")
                    
                    self.Aviso.text = "User created successfully."
                    self.Aviso.textColor = UIColor.green.withAlphaComponent(1)
                    self.BotonRegistrarse.alpha = 0
                    self.Confirmar.alpha = 1
                    
            let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                changeRequest?.displayName = self.Usuario.text!
                }else{
                    self.Aviso.textColor = UIColor.red
                    self.Aviso.text = ("\(error!.localizedDescription)")
                }
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        Usuario.resignFirstResponder()
        Correo.resignFirstResponder()
        Contraseña.resignFirstResponder()
        return (true)
    }
    
    func updateUI()
    {
        vistaDeCategorias.isHidden = true
        vistaDelRegistroFinal.isHidden = true
        Imagen.isHidden = false
        
            categorias.text = " 〰️Categorias〰️ "
            stack1DeCat.isHidden = false
            cat1.text = "Arte y Cultura 🎭"
            switch1.isOn = false
            stack2DeCat.isHidden = false
            cat2.text = "Ciencia ⚗️"
            switch2.isOn = false
            stack3DeCat.isHidden = false
            cat3.text = "Educación 👨‍🏫"
            switch3.isOn = false
            stack4DeCat.isHidden = false
            cat4.text = "Tecnología 🤖"
            switch4.isOn = false
            stack5DeCat.isHidden = false
            cat5.text = "Deporte 🏃‍♂️"
            switch5.isOn = false
            stack6DeCat.isHidden = false
            cat6.text = "Social 👥"
            switch6.isOn = false
        //}
        
    }
    
    @IBAction func pasados(_ sender: Any) {
    if vistaDeCategorias.isHidden == false
    {
        if switch1.isOn == true
        {
            catElegidas.append("Arte y Cultura 🎭")
        }
        if switch2.isOn == true
        {
            catElegidas.append("Ciencia ⚗️")
        }
        if switch3.isOn == true
        {
            catElegidas.append("Educación 👨‍🏫")
        }
        if switch4.isOn == true
        {
            catElegidas.append("Tecnología 🤖")
        }
        if switch5.isOn == true
        {
            catElegidas.append("Deporte 🏃‍♂️")
        }
        if switch6.isOn == true
        {
            catElegidas.append("Social 👥")
        }
        print(catElegidas)

        vistaDeCategorias.isHidden = true
        vistaDelRegistroFinal.isHidden = false
    }
    if vistaDelRegistroFinal.isHidden == false
    {
    
    botonDeContinuar.alpha = 0
    
    cambiaElProgresoDelRegistro += 1
    progresoDelRegistro.setProgress(Float(cambiaElProgresoDelRegistro), animated: true)
    
    }
        
    }
    @IBAction func pasa(_ sender: Any)
{
      if Imagen.isHidden == false
      {
            Imagen.isHidden = true
        }
            if Imagen.isHidden == true
            {
               vistaDeCategorias.isHidden = false
                cambiaElProgresoDelRegistro += 0.5
                progresoDelRegistro.setProgress(Float(cambiaElProgresoDelRegistro), animated: true)
                
                
    
}
}
}
extension RegistroDelUsuarioViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage {
            self.Foto.image = pickedImage
        }
        
        picker.dismiss(animated: true, completion: nil)
    }
    
}

