//
//  EventoViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class EventosMasRecientesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
   
    @IBOutlet weak var tablita: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tablita.delegate = self
        tablita.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tablita.numberOfSections == 1
        {
            let cel = tablita.dequeueReusableCell(withIdentifier: "evento", for: indexPath)
            cel.backgroundColor = UIColor.red
            return cel
        }
        else
        {
            let cel = tablita.dequeueReusableCell(withIdentifier: "evento", for: indexPath)
            cel.backgroundColor = UIColor(red: 2.0, green: 1.0, blue: 0.5, alpha: 0.3)
            cel.textLabel?.text = "Soy la celda mas verguera la numero \(indexPath.row)"
            cel.layer.borderWidth = 5
            cel.layer.cornerRadius = 10
            cel.imageView?.layer.cornerRadius = 20
            cel.imageView?.layer.borderWidth = 2
            return cel
        }
    }
    
}
    

